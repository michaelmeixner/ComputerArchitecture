//Michael Meixner, Lab 7

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DATA_FILE "timedata.dat"

int main() 
{
    printf("\n\nFile Data:\n");
    FILE *inputFile = NULL;
    if((inputFile = fopen(DATA_FILE, "r")) == NULL) 
    {
         printf("Error opening file %s for input!\n", DATA_FILE);
        exit(0);
    }

    int hours = 0;
    int minutes = 0;
    int minutesMask = 4032; 
    int seconds = 0;
    int mask = 63;
    while(!feof(inputFile)) 
    {
        int time = 0;
        if(fread(&time, sizeof(int), 1, inputFile)) 
        {
            //do work here
            hours = time >> 12;
            // minutes = (time & minutesMask) >> 6;
            minutes = (time >> 6) & mask;
            seconds = (time) & mask;
        }
    }
    printf("%02d:", hours);
    printf("%02d:", minutes);
    printf("%02d\n", seconds);
    fclose(inputFile), inputFile = NULL;
}